﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EVALUACION_T2
{
    public class Menu
    {
        public static int ElijeOpcion() 
        {
            int opcion = 0;

            do
            {
                Console.WriteLine("=====================================");
                Console.WriteLine("SISTEMA DE GESTION DE TRANSPORTE");
                Console.WriteLine("=====================================");
                Console.WriteLine("[1] - VENTA DE PASAJES");
                Console.WriteLine("[2] - EQUIPAJE Y ENCOMIENDAS");
                Console.WriteLine("[3] - GESTIONAR CARGA");
                Console.WriteLine("[4] - SALIR DEL PROGRAMA");
                Console.WriteLine("=====================================");
                Console.Write("\nIngrese una de las opciones del [1-4]: ");

                string entrada = Console.ReadLine();

                if (int.TryParse(entrada, out opcion)) 
                {
                    if (opcion < 1 || opcion > 4)
                    {
                        Console.WriteLine("Opcion invalida. Por favor, ingrese un numero entre 1 y 4.\n");
                    }
                }
                else
                {
                    Console.WriteLine("Entrada invalida. Por favor, ingrese un numero valido.\n");
                }

            } while (opcion < 1 || opcion > 4);

            return opcion;
        }
    }
}
