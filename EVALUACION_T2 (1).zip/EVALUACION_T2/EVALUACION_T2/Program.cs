﻿using BIBLIOTECA_1A;
using Biblioteca2;
using BibliotecaEquipaje;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace EVALUACION_T2
{
    class Program
    {
        static void Main()
        {
            Menu menu = new Menu();
            int opcion = 0;

            do 
            {
                opcion = Menu.ElijeOpcion();

                switch (opcion) 
                {
                    case 1:
                        Console.WriteLine("Ha seleccionado VENTA DE PASAJES.\n");
                        break;
                    case 2:
                        Console.WriteLine("Ha seleccionado EQUIPAJE Y ENCOMIENDAS.\n");
                        break;
                    case 3:
                        Console.WriteLine("Ha seleccionado GESTIONAR CARGA.\n");
                        break;
                    case 4:
                        Console.WriteLine("Ha seleccionado SALIR DEL PROGRAMA.\n");
                        break;
                }
            }while (opcion != 4);

        }

    }
}
namespace BIBLIOTECA_1A
{
    public class ClaseVenta
    {
        public void VentaPasaje()
        {
            string dni;
            int contador;
            while (true)
            {
                Console.Write("Ingrese su DNI: ");
                dni = Console.ReadLine();
                contador = 0;
                bool esNumerico = true;

                int i = 0;
                while (true)
                {
                    if (i >= dni.Length)
                        break;

                    contador++;

                    if (dni[i] < '0' || dni[i] > '9')
                    {
                        esNumerico = false;
                        break;
                    }

                    i++;
                }

                if (contador == 8 && esNumerico)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("DNI inválido. Debe tener exactamente 8 dígitos numéricos.");
                }
            }

            int asiento;
            while (true)
            {
                Console.Write("Ingrese el número de asiento (1 al 30): ");
                string input = Console.ReadLine();
                bool esValido = Int32.TryParse(input, out asiento);

                if (esValido && asiento >= 1 && asiento <= 30)
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Número de asiento no válido. Debe estar entre 1 y 30.");
                }
            }

            string tipoAsiento = "";
            double costo = 0;

            if (asiento >= 1 && asiento <= 10)
            {
                tipoAsiento = "VIP";
                costo = 75.00;
            }
            else if (asiento >= 11 && asiento <= 20)
            {
                tipoAsiento = "EJECUTIVO";
                costo = 50.00;
            }
            else
            {
                tipoAsiento = "ECONÓMICO";
                costo = 35.50;
            }
            Console.WriteLine("\n--- DETALLE DE LA VENTA ---");
            Console.WriteLine("DNI del pasajero: " + dni);
            Console.WriteLine("Número de asiento: " + asiento);
            Console.WriteLine("Tipo de asiento: " + tipoAsiento);
            Console.WriteLine("Costo del pasaje: S/ " + costo);
            Console.WriteLine("---------------------------\n");
        }
    }
}
namespace MainApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Equipaje eq = new Equipaje();
            eq.RegistrarEquipaje();
        }
    }
}


class Program

{

    static void Main()

    {

        var carga = new ClaseCarga();

        carga.GestionCarga();

    }

}
