﻿using System;



namespace Biblioteca2

{

    public class ClaseCarga

    {

        public void GestionCarga()

        {

            Console.WriteLine("-------------------------------------------------");

            Console.WriteLine("          GESTIÓN DE CARGA       ");

            Console.WriteLine("-------------------------------------------------");



            Console.Write("Carga a transportar: ");

            string carga = Console.ReadLine().ToLower();



            string[] cargasValidas = { "alimentos", "mercadería", "muebles", "varios" };

            if (Array.IndexOf(cargasValidas, carga) == -1)

            {

                Console.WriteLine("Tipo de carga no válida.");

                return;

            }



            Console.Write("Ancho de la carga (m): ");

            if (!double.TryParse(Console.ReadLine(), out double ancho))

            {

                Console.WriteLine("Ancho inválido.");

                return;

            }



            Console.Write("Largo de la carga (m): ");

            if (!double.TryParse(Console.ReadLine(), out double largo))

            {

                Console.WriteLine("Largo inválido.");

                return;

            }



            Console.Write("Alto de la carga (m): ");

            if (!double.TryParse(Console.ReadLine(), out double alto))

            {

                Console.WriteLine("Alto inválido.");

                return;

            }



            Console.Write("Peso de la carga (toneladas): ");

            if (!double.TryParse(Console.ReadLine(), out double peso))

            {

                Console.WriteLine("Peso inválido.");

                return;

            }



            if (largo > 13 || ancho > 2.40 || alto > 3.4)

            {

                Console.WriteLine("Una o más dimensiones superan las permitidas.");

                return;

            }



            if (peso > 30)

            {

                Console.WriteLine("El peso excede las 30 toneladas.");

                return;

            }



            double volumen = largo * ancho * alto;



            Console.WriteLine("\nResumen de la carga enviada:");

            Console.WriteLine($"Tipo de carga: {carga}");

            Console.WriteLine($"Volumen de carga (m³): {volumen}");

            Console.WriteLine($"Peso total de la carga (toneladas): {peso}");

        }

    }

}