﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BIBLIOTECA_1
{
    public class Cajero
    {
        double saldo = 1000;

        public double consultar()
        {
            return saldo;
        }

        public void depositar(double monto)
        {
            while (true)
            {
                Console.Write("\nIngrese el monto a DEPOSITAR: ");
                string en = Console.ReadLine();
                {

                    try
                    {
                        monto = Convert.ToDouble(en);

                        if (monto > 0)
                        {
                            saldo += monto;
                            Console.WriteLine("Deposito exitoso.");
                            break;
                        }
                        else
                            Console.WriteLine(("Error. tiene que ser un deposito mayor a 0. \n"));
                        continue;
                    }
                    catch (Exception)
                    {
                        Console.WriteLine(("Error. tiene que ser un deposito un monto valido"));
                    }
                }
            }
        }

                    public void retirar(double monto)
        {
            while (true)
            {
                Console.Write("\nIngrese el monto a RETIRAR: ");
                string en = Console.ReadLine();
                {

                    try
                    {
                        monto = Convert.ToDouble(en);

                        if (monto <= 0)
                        {
                            saldo -= monto;
                            Console.WriteLine("Deposito exitoso.");
                            break;
                        }
                        else if (monto < 0)
                        {
                            Console.WriteLine(("Error. tiene que ser un retiro mayor a 0. \n"));
                            continue;
                        }
                        else
                        {
                            Console.WriteLine(("Error. tiene que ser un deposito mayor a 0. \n"));
                            continue;
                        }
                    }
                    catch (Exception)
                    {
                        Console.WriteLine(("Error. tiene que ser un deposito un monto valido"));
                    }

                }
            }
        }
    }
}
